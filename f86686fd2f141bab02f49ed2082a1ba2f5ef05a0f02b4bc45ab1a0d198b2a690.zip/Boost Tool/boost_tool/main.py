from boosting import *
import httpx, random, time, datetime, json, os, hashlib
from keyauth import api
import webbrowser

if os.name == 'nt':
    import ctypes

def cls():
    os.system('cls' if os.name =='nt' else 'clear')

if os.name == "nt":
    ctypes.windll.kernel32.SetConsoleTitleW(f"Tools Realm | Boost Tool | V1")
else:
    pass
    
config = json.load(open("config.json", encoding="utf-8"))



def getinviteCode(invite_input): #gets invite CODE
    if "discord.gg" not in invite_input:
        return invite_input
    if "discord.gg" in invite_input:
        invite = invite_input.split("discord.gg/")[1]
        return invite
    if "https://discord.gg" in invite_input:
        invite = invite_input.split("https://discord.gg/")[1]
        return invite
    if "invite" in invite_input:
        invite = invite_input.split("/invite/")[1]
        return invite

def menu():
    print('''______                 _     _____           _ 
| ___ \               | |   |_   _|         | |
| |_/ / ___   ___  ___| |_    | | ___   ___ | |
| ___ \/ _ \ / _ \/ __| __|   | |/ _ \ / _ \| |
| |_/ / (_) | (_) \__ \ |_    | | (_) | (_) | |
\____/ \___/ \___/|___/\__|   \_/\___/ \___/|_|
''')
    print('~ [ - ] Made by @xyzdivine\n')
    print('~ [ 1 ] Boost')
    print('~ [ 2 ] Stock')
    print('~ [ 3 ] Exit')
    
    #sprint("Test 1", True)
    #sprint("Test 1", False)
    choice = input('\n~ [ - ] Option: ')
    cls()
    
    

    if choice == "1":
        invite = getinviteCode(input('~ [ - ] Invite Link: '))
        amount = input('~ [ - ] Boosts: ')
        while amount.isdigit() != True:
            print('~ [ - ] Invalid Amount')
            amount = input('~ [ - ] Boosts: ')
        months = input('~ [ - ] 1/3 Month: ')
        while amount.isdigit() != True:
            print('~ [ - ] Invalid Amount')
            months = input('~ [ - ] 1/3 Month: ')
        start = time.time()
        boosted = thread_boost(invite, int(amount), int(months), config['nickname'], config["bio"])
        end = time.time()
        print()
        sprint(f"~ [ - ] Boosted https://discord.gg/{invite} {variables.boosts_done} times in {round(end - start, 2)} seconds.", True)
        print()
        input('~ [ - ] Press enter to return to menu')
        cls()
        menu()
        
    if choice == "2":
        print(f'~ [ - ] 1 Month Nitro Tokens: {len(open("input/1m_tokens.txt", "r").readlines())}')
        print(f'~ [ - ] 1 Month Boosts: {len(open("input/1m_tokens.txt", "r").readlines())*2}')
        print()
        print(f'~ [ - ] 3 Month Nitro Tokens: {len(open("input/3m_tokens.txt", "r").readlines())}{Fore.RESET}')
        print(f'~ [ - ] 3 Month Boosts: {len(open("input/3m_tokens.txt", "r").readlines())*2}{Fore.RESET}')
        print()
        print('~ [ - ] Note: This only checks for validity of tokens, not if they have nitro')
        input('~ [ - ] Press enter to return to menu')
        cls()
        menu()
        
    if choice == "3":
        quit()
        
if __name__ == "__main__":
    cls()
    menu()